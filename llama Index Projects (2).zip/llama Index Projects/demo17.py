from llama_index.core import VectorStoreIndex, SimpleDirectoryReader
from llama_index.llms.openai import OpenAI
from llama_index.llms.anthropic import Anthropic
import os

os.environ["OPENAI_API_KEY"] = "sk-proj-rWgqmTVyDuAzrw2IliBGT3BlbkFJSjAp34ZeNeJw184bpnkg"

llm = Anthropic()
data = SimpleDirectoryReader(input_dir="C:\\Users\\gunti\\OneDrive\\Desktop\\llama Index Projects\\data\\paul_graham\\").load_data()
index = VectorStoreIndex.from_documents(data)
chat_engine = index.as_chat_engine(llm=llm, chat_mode="react", verbose=True)
response = chat_engine.chat(
    "Use the tool to answer what did Paul Graham do in the summer of 1995?"
)
print(response)

