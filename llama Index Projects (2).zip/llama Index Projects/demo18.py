from llama_index.core.chat_engine import SimpleChatEngine
import os

os.environ["OPENAI_API_KEY"] = "sk-proj-rWgqmTVyDuAzrw2IliBGT3BlbkFJSjAp34ZeNeJw184bpnkg"

chat_engine = SimpleChatEngine.from_defaults()
chat_engine.chat_repl()

