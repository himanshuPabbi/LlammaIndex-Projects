from llama_index.llms.openai import OpenAI
from llama_index.core.chat_engine import SimpleChatEngine

import os
llm = OpenAI(temperature=0.0, model="gpt-3.5-turbo")
os.environ["OPENAI_API_KEY"] = "sk-proj-rWgqmTVyDuAzrw2IliBGT3BlbkFJSjAp34ZeNeJw184bpnkg"

chat_engine = SimpleChatEngine.from_defaults(llm=llm)
chat_engine.chat_repl()

