from llama_index.core import KeywordTableIndex, SimpleDirectoryReader
from llama_index.llms.openai import OpenAI
import os

os.environ["OPENAI_API_KEY"] = "sk-proj-rWgqmTVyDuAzrw2IliBGT3BlbkFJSjAp34ZeNeJw184bpnkg"

# alternatively
# from langchain.llms import ...

documents = SimpleDirectoryReader("data").load_data()

# define LLM
llm = OpenAI(temperature=0.1, model="gpt-4")

# build index
index = KeywordTableIndex.from_documents(documents, llm=llm)

# get response from query
query_engine = index.as_query_engine()
response = query_engine.query(
    "How would you describe the appearance of the bookstore's sign?"
)
print(response)

