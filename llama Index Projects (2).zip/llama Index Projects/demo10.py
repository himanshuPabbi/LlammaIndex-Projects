import os
import streamlit as st
from llama_index.core import VectorStoreIndex, SimpleDirectoryReader

# Set your OpenAI API key as an environment variable
os.environ["OPENAI_API_KEY"] = "sk-proj-rWgqmTVyDuAzrw2IliBGT3BlbkFJSjAp34ZeNeJw184bpnkg"

def main():
    st.title("Vector Index Query")

    # Assuming SimpleDirectoryReader loads data correctly from "data" directory
    documents = SimpleDirectoryReader("data").load_data()

    # Assuming VectorStoreIndex.from_documents() indexes documents correctly
    index = VectorStoreIndex.from_documents(documents)

    # Assuming index.as_query_engine() creates a query engine correctly
    query_engine = index.as_query_engine()

    # Input field for query
    query = st.text_input("Enter your query:")

    # Query the index on button press
    if st.button("Search"):
        if query:
            response = query_engine.query(query)
            st.write("Response:", response)
        else:
            st.warning("Please enter a query.")

if __name__ == "__main__":
    main()
