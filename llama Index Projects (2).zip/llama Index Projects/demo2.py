import os
from llama_index.core import VectorStoreIndex, SimpleDirectoryReader

# Set your OpenAI API key as an environment variable
os.environ["OPENAI_API_KEY"] = "sk-proj-rWgqmTVyDuAzrw2IliBGT3BlbkFJSjAp34ZeNeJw184bpnkg"

# Assuming SimpleDirectoryReader loads data correctly from "data" directory
documents = SimpleDirectoryReader("data").load_data()

# Assuming VectorStoreIndex.from_documents() indexes documents correctly
index = VectorStoreIndex.from_documents(documents)

# Assuming index.as_query_engine() creates a query engine correctly
query_engine = index.as_query_engine()

response = query_engine.query("Where is the bookstore located?")
print(response)
    