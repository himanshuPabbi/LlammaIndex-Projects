import os

from llama_index.llms.openai import OpenAI
os.environ["OPENAI_API_KEY"] = "sk-proj-rWgqmTVyDuAzrw2IliBGT3BlbkFJSjAp34ZeNeJw184bpnkg"

# non-streaming
resp = OpenAI().complete("Paul Graham is ")
print(resp)
