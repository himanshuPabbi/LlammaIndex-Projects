from llama_index.core import VectorStoreIndex, SimpleDirectoryReader
from llama_index.llms.openai import OpenAI
import os

os.environ["OPENAI_API_KEY"] = "sk-proj-rWgqmTVyDuAzrw2IliBGT3BlbkFJSjAp34ZeNeJw184bpnkg"

# Necessary to use the latest OpenAI models that support function calling API
llm = OpenAI(model="gpt-4o")
data = SimpleDirectoryReader(input_dir="C:\\Users\\gunti\\OneDrive\\Desktop\\llama Index Projects\\data\\paul_graham\\").load_data()
index = VectorStoreIndex.from_documents(data)
chat_engine = index.as_chat_engine(chat_mode="openai", llm=llm, verbose=True)
response = chat_engine.chat("Hi")
print(response)


response = chat_engine.chat(
    "What did Paul Graham do growing up?", tool_choice="query_engine_tool"
)
print(response)

