import os
import streamlit as st
from llama_index.core import KeywordTableIndex, SimpleDirectoryReader
from llama_index.llms.openai import OpenAI

# Set OpenAI API key
os.environ["OPENAI_API_KEY"] = "sk-proj-rWgqmTVyDuAzrw2IliBGT3BlbkFJSjAp34ZeNeJw184bpnkg"

# Load documents
documents = SimpleDirectoryReader("C:\\Users\\gunti\\OneDrive\\Desktop\\llama Index Projects\\data").load_data()

# Define LLM
llm = OpenAI(temperature=0.1, model="gpt-4")

# Build index
index = KeywordTableIndex.from_documents(documents, llm=llm)

# Create a Streamlit app
st.title("Bookstore Query System")

# Input box for user query
user_query = st.text_input("Ask a question about the bookstore:")

if user_query:
    # Get response from query
    query_engine = index.as_query_engine()
    response = query_engine.query(user_query)
    
    # Display the response
    st.write("Response:")
    st.write(response.response)  # Display response text
    
    # Display source nodes if available
    if response.source_nodes:
        st.write("Source Information:")
        for node in response.source_nodes:
            # Extract metadata from node
            metadata = node.node.metadata
            file_info = (
                f"File Path: {metadata.get('file_path', 'N/A')}\n"
                f"File Name: {metadata.get('file_name', 'N/A')}\n"
                f"File Type: {metadata.get('file_type', 'N/A')}\n"
                f"File Size: {metadata.get('file_size', 'N/A')} bytes\n"
                f"Creation Date: {metadata.get('creation_date', 'N/A')}\n"
                f"Last Modified Date: {metadata.get('last_modified_date', 'N/A')}"
            )
            st.write(file_info)
            st.write("---")
