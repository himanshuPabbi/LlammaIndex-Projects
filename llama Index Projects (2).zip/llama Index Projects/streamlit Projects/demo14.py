import os
import streamlit as st
from llama_index.core import VectorStoreIndex, SimpleDirectoryReader
from llama_index.llms.openai import OpenAI

# Set OpenAI API key
os.environ["OPENAI_API_KEY"] = "sk-proj-rWgqmTVyDuAzrw2IliBGT3BlbkFJSjAp34ZeNeJw184bpnkg"

# Initialize the LLM
llm = OpenAI(model="gpt-4")

# Load data and create the index
data = SimpleDirectoryReader(input_dir="C:\\Users\\gunti\\OneDrive\\Desktop\\llama Index Projects\\data\\paul_graham\\").load_data()
index = VectorStoreIndex.from_documents(data)

# Initialize the chat engine
chat_engine = index.as_chat_engine(chat_mode="openai", llm=llm, verbose=True)

# Streamlit app
st.title("OpenAI Chat Interface")

# Input box for user query
user_input = st.text_input("You:", "")

if user_input:
    try:
        # Get response from the chat engine
        response = chat_engine.chat(user_input)
        
        # Extract the main answer and sources from the response
        main_answer = response.response
        sources = response.sources
        
        # Display the main response
        st.write("Response:")
        st.write(main_answer)
        
        # Display sources if available
        if sources:
            st.write("Sources:")
            for source in sources:
                st.write(source.content)
        else:
            st.write("No sources available.")
    
    except Exception as e:
        st.error(f"An error occurred: {e}")
