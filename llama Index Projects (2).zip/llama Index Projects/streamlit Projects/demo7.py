import os
import openai
import streamlit as st
from llama_index.core.llms import ChatMessage

# Set OpenAI API key
os.environ["OPENAI_API_KEY"] = "sk-proj-rWgqmTVyDuAzrw2IliBGT3BlbkFJSjAp34ZeNeJw184bpnkg"
openai.api_key = os.getenv("OPENAI_API_KEY")

# Initialize OpenAI chat model
def get_chat_response(messages):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # You can also use "gpt-4" if you have access
        messages=[{"role": msg.role, "content": msg.content} for msg in messages]
    )
    return response.choices[0].message['content']

# Streamlit app
st.title("OpenAI Chat Interface")

# Maintain conversation history
if 'messages' not in st.session_state:
    st.session_state.messages = [
        ChatMessage(role="system", content="You are a pirate with a colorful personality")
    ]

# Input box for user message
user_input = st.text_input("You: ")

if user_input:
    # Add user message to the conversation history
    st.session_state.messages.append(ChatMessage(role="user", content=user_input))
    
    # Get response from OpenAI
    response_content = get_chat_response(st.session_state.messages)
    
    # Add OpenAI response to the conversation history
    st.session_state.messages.append(ChatMessage(role="assistant", content=response_content))
    
    # Display the conversation
    st.write("Conversation:")
    for msg in st.session_state.messages:
        st.write(f"**{msg.role.capitalize()}:** {msg.content}")

