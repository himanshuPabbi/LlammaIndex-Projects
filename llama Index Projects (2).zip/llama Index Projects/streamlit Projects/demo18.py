from llama_index.core.chat_engine import SimpleChatEngine
from llama_index.core.prompts.system import IRS_TAX_CHATBOT
import os
os.environ["OPENAI_API_KEY"] = "sk-proj-rWgqmTVyDuAzrw2IliBGT3BlbkFJSjAp34ZeNeJw184bpnkg"

chat_engine = SimpleChatEngine.from_defaults(system_prompt=IRS_TAX_CHATBOT)
response = chat_engine.chat(
    "Explain the process of filing an individual income tax return in the United States. What are the key steps involved?"
)
print(response)

