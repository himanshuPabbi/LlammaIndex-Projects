import os
import openai
import streamlit as st

# Set OpenAI API key
os.environ["OPENAI_API_KEY"] = "sk-proj-rWgqmTVyDuAzrw2IliBGT3BlbkFJSjAp34ZeNeJw184bpnkg"

# Initialize OpenAI API key
openai.api_key = os.getenv("OPENAI_API_KEY")

# Streamlit app
st.title("OpenAI Completion Generator")

# Input box for user prompt
user_prompt = st.text_input("Enter your prompt:")

if user_prompt:
    try:
        # Generate completion from OpenAI
        response = openai.Completion.create(
            engine="text-davinci-003",  # or "text-davinci-002" or "gpt-3.5-turbo" for different engines
            prompt=user_prompt,
            temperature=0.7,
            max_tokens=150
        )
        
        # Display the completion response
        st.write("Response:")
        st.write(response.choices[0].text.strip())
    except Exception as e:
        st.error(f"An error occurred: {e}")
