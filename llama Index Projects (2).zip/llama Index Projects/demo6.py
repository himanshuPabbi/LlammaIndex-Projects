from llama_index.llms.openai import OpenAI
import os

os.environ["OPENAI_API_KEY"] = "sk-proj-rWgqmTVyDuAzrw2IliBGT3BlbkFJSjAp34ZeNeJw184bpnkg"

# non-streaming
completion = OpenAI().complete("Paul Graham is ")
print(completion)

# using streaming endpoint
from llama_index.llms.openai import OpenAI

llm = OpenAI()
completions = llm.stream_complete("Paul Graham is ")
for completion in completions:
    print(completion.delta, end="")


    