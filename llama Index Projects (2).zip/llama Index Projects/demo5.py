from llama_index.core import Settings
import tiktoken

# Set tokenizer using tiktoken for "gpt-3.5-turbo"
Settings.tokenizer = tiktoken.encoding_for_model("gpt-3.5-turbo").encode

def tokenize_text(text):
    # Use the configured tokenizer
    tokenizer = Settings.tokenizer
    
    # Tokenize the input text
    tokens = tokenizer.tokenize(text)
    
    return tokens

# Example usage
input_text = "This is a sample sentence for tokenization."
tokens = tokenize_text(input_text)
print("Tokens:", tokens)
